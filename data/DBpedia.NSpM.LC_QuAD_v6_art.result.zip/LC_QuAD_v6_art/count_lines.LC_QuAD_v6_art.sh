#!/bin/bash
#!/usr/bin/php

NUMLINES= $(echo awk '{ print $1}' | cat data/LC_QuAD_v6_art/data_300.sparql |  wc -l)
echo $NUMLINES

#Split the `data_.*` files into `train_.*`, `dev_.*`, and `test_.*` (usually 80-10-10%).

cd data/LC_QuAD_v6_art/
python ../../split_in_train_dev_test.py --lines $NUMLINES  --dataset data.sparql
